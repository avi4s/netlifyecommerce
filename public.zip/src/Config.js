const Url = "https://fakestoreapi.com/";
const BaseUrl = Url + "products/";
export default BaseUrl;
