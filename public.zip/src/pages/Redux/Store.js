import { createStore, applyMiddleware } from "redux";
import thunk from "redux-thunk";
import rootReducer from "./Reducer";
// import cartReducer from "./Reducer/CartReducer";

const store = createStore(rootReducer, applyMiddleware(thunk));
export default store;
